package testCases;

import utility.BaseClass;
import utility.BrowserConfig;
import utility.GlobalVariables;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import pageActions.LoginPageActions;
import pageObject.LoginPage;

public class LoginPageTest extends BaseClass {

	private WebDriver driver = null;
	BrowserConfig browserConfig = new BrowserConfig();
	LoginPageActions loginPage = new LoginPageActions();

//	test cases

	@BeforeSuite
	public void beforeSuite() {
		GlobalVariables.driver = browserConfig.browserLaunch(GlobalVariables.browser);
		this.driver = GlobalVariables.driver;
	}

	@Test(priority = 1)
	public void launchURL() {
		driver.get(URL);
		implicitWait(10);
	}

	@Test(priority = 2)
	public void pageLogin() {
		loginPage.enter_Username(username);
		loginPage.enter_Password(password);
		loginPage.click_Login();
	}

//	@Test
//	public void Login() throws InterruptedException {
//		BrowserConfig.browserLaunch(GlobalVariables.browser);
//		GlobalVariables.driver.get(GlobalVariables.URL);
//		loginPage = new LoginPage();
//		System.out.println(GlobalVariables.username);
//		loginPage.enter_Username(GlobalVariables.username);
//		Thread.sleep(2000);
//		loginPage.enter_Password(GlobalVariables.password);
//		Thread.sleep(2000);
//		loginPage.click_Login();
//		Thread.sleep(2000);
//	}
}