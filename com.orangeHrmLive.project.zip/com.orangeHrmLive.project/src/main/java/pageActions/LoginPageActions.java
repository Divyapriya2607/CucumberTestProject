package pageActions;

import org.openqa.selenium.support.PageFactory;

import pageObject.LoginPage;
import utility.BaseClass;
import utility.GlobalVariables;

public class LoginPageActions extends BaseClass {

	LoginPage loginPage = new LoginPage();

//	public LoginPageActions() {
//		PageFactory.initElements(GlobalVariables.driver, this);
//	}

	public void enter_Username(String input) {
//		textBox(loginPage.textBox_Username, input);
		textBox(loginPage.txtBoxUsername(), input);
	}

	public void enter_Password(String input) {
		textBox(loginPage.textBox_Password, input);
	}

	public void click_Login() {
		click(loginPage.button_Login);
	}

}