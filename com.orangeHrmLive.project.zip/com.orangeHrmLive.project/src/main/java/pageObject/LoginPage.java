package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import pageActions.LoginPageActions;
import utility.GlobalVariables;

public class LoginPage {
	// public WebDriver driver;
//	web page related locators
	
//	public LoginPage() {
//		// this.driver=GlobalVariables.driver;
//		PageFactory.initElements(GlobalVariables.driver, this);
//	}

	@FindBy(xpath = "//form//input[@name='username']")
	public WebElement textBox_Username;

	@FindBy(xpath = "//form//input[@name='password']")
	public WebElement textBox_Password;

	@FindBy(xpath = "//form//button[@type='submit']")
	public WebElement button_Login;
	
	public WebElement txtBoxUsername() {
		return GlobalVariables.driver.findElement(By.xpath("//form//input[@name='username']"));
	}

//	public void enter_Username(String input) {
//		new BaseClass().textBox(textBox_Username, input);
//	}
//	public void enter_Password(String input) {
//		new BaseClass().textBox(textBox_Password,input);
//	}
//	public void click_Login() {
//		new BaseClass().click(button_Login);
//	}

}