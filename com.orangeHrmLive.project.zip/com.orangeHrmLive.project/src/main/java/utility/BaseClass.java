package utility;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class BaseClass extends GlobalVariables {
	// public WebDriver driver;

//	public BaseClass() {
//		// this.driver=GlobalVariables.driver;
//		PageFactory.initElements(driver, this);
//	}

//	Selenium related actions
	public void dropDown(WebElement element, int input) {
		Select select = new Select(element);
		select.selectByIndex(input);

	}

	public void textBox(WebElement element, String input) {
		element.sendKeys(input);
	}

	public void click(WebElement element) {
		element.click();
	}

	public void implicitWait(long timeInSec) {
//		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(timeInSec));
	}

}