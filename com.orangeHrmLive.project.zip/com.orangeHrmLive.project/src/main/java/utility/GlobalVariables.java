package utility;

import org.openqa.selenium.WebDriver;

public class GlobalVariables {

//	Variables to be used through out the project
	public static final String URL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
	public static WebDriver driver;
	public static final String username="Admin";
	public static final String password="admin123";
	public static final String browser="chrome";
	
}